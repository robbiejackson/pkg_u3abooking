<?php
namespace Robbie\Component\U3ABooking\Administrator\Controller;

/**
 * Controller for handling event.xxx tasks
 */
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\MVC\Controller\FormController;

class EventController extends FormController
{

}
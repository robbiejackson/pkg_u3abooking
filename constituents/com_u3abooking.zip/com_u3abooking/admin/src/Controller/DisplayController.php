<?php
namespace Robbie\Component\U3ABooking\Administrator\Controller;

defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\MVC\Controller\BaseController;

class DisplayController extends BaseController
{
	protected $default_view = 'events';
}
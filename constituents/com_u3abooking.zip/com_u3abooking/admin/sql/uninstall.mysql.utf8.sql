DROP TABLE IF EXISTS `#__u3a_event`;
DROP TABLE IF EXISTS `#__u3a_booking`;
DELETE FROM `#__categories` WHERE `extension` = 'com_u3abooking';